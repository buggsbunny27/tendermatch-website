document.querySelector('.nav-toggle')?.addEventListener('click',()=>{
  const nav=document.getElementById('nav');
  const expanded=nav.classList.toggle('open');
});